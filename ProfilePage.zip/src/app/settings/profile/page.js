'use client'
import ProfilePageIndex from '@/components/ProfilePage/ProfilePage.Index'
import Image from 'next/image'

export default function Profile() {
  return (
   <div className=''>
   
   <ProfilePageIndex/>
   </div>
  )
}
